from whole_blur import WholeBlur
from blurred_context import BlurredContext
from unconventional_size import UnconventionalSize
from pattern import Pattern
from exposure import Exposure
from small_object import ObjectTooSmall
from multiple_salient_regions import MultipleSalientRegions
from hdr import HDR
from posterized import Posterized
from cross_processed import CrossProcessed
from framed import Framed
from highlights import Highlights
from text_detection import TextDetection

